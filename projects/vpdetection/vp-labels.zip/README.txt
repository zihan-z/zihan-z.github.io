This folder contains the manually labelled dominant vanishing point locations (in terms of two converging lines) for:
(1) The images in the "landscape" category of the AVA dataset. Out of 21,982 images in the category, we determined that 1,316 images have a dominant vanishing point. Each file name in this folder corresponds to an image ID in the AVA dataset.
(2) 959 images from Flickr that have a dominant vanishing point. The file name corresponds to the image ID on flickr.com.

The format of each file is as follows:

width height
x1 y1 x2 y2 // line 1
x1 y1 x2 y2 // line 2

Questions? Zihan Zhou (zzhou@ist.psu.edu)